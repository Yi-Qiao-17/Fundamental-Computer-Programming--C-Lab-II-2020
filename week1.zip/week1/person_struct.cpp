// Demonstrates how to rewrite c++ struct to c++ class

#include <iostream>
#include <string>
#include <sstream>
using namespace std;
 
struct person
{
    string name;
    int age;
};

string toString(person &pn)
{
    ostringstream stringStream;
    stringStream << "Name: " << pn.name << ", " << "Age: " << pn.age;
    return stringStream.str();
}
 
int main()
{
  person a, b;
  a.name = "Calvin";
  b.name = "Hobbes";
  a.age = 30;
  b.age = 20;
  cout << toString(a) << endl;
  cout << toString(b) << endl;
  return 0;
}

