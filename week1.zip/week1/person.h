// Demonstrates how to rewrite c++ struct to c++ class
#ifndef PERSON_H
#define PERSON_H

using namespace std;
class person {
    private:
        // member variables
        string name;
        int age;
    public:
        // constructor function
        //person( string, int );
        person( string = "noname", int = 5 );
        // member functions
        void setName( string );
        void setAge( int );
        string toString();
};

#endif // PERSON_H
