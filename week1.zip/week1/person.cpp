// Demonstrate how to rewrite c++ struct to c++ class

#include <iostream>
#include <sstream>
#include "person.h"
using namespace std;

person::person(string nm, int ae)
{
    setName(nm);
    setAge(ae);
}

void person::setName( string nm )
{
    name = nm;
}

void person::setAge( int ae )
{
    age = ae;
}

string person::toString()
{
    ostringstream stringStream;
    stringStream << "Name: " << name << ", " << "Age: " << age;
    return stringStream.str();
}
