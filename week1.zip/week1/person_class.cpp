// Demonstrate how to rewrite c++ struct to c++ class

#include <iostream>
#include "person.h"

int main(int argc, const char *argv[])
{
    person noname;
    person tom("Tom", 20 );

    cout << noname.toString() << endl;
    cout << tom.toString() << endl;
    return 0;
}
