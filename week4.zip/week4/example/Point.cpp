// The implenment of Class Point
#include "Point.h"

Point Point::operator+(Point &rightPoint)
{
    return Point(coordX + rightPoint.coordX, coordY + rightPoint.coordY);
}

Point Point::operator-(Point &rightPoint)
{
    return Point(coordX - rightPoint.coordX, coordY - rightPoint.coordY);
}

ostream& operator<<(ostream &out, const Point &outPoint)
{
    out << "(" << outPoint.coordX << "," << outPoint.coordY << ")" << endl;
    return out;
} 

istream& operator>>(istream &in, Point &outPoint)
{
    in >> outPoint.coordX >> outPoint.coordY;
    return in;
}
