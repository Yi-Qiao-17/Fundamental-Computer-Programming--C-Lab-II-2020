// Test Class Point
#include "Point.h"

int main(int argc, const char *argv[])
{
    Point a(1,1);
    Point b(0,0);
    cin >> b;
    cout << a + b;
    cout << a - b;
    return 0;
}
