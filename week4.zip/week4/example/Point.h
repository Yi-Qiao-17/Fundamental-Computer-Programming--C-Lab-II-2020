// The definition of Class Point
#ifndef POINT_H
#define POINT_H
#include <iostream>
using namespace std;
class Point {
    friend ostream& operator<<(ostream &out, const Point &outPoint);
    friend istream& operator>>(istream &in, Point &outPoint);

    private:
        int coordX,coordY;
    public:
        Point(int x, int y):coordX(x),coordY(y){}
        Point operator+(Point &rightPoint);
        Point operator-(Point &rightPoint);
};
#endif /* POINT_H */
