// The example of C++ Class
#ifndef ARRAY_H
#define ARRAY_H
#include <iostream>

using namespace std;

class Array {
    public:
        Array(int s);
        ~Array();
        void setValue(int index, int value);
        int getValue(int index);
    private:
        int Size;
        int *ArrayPtr;
};

#endif // ARRAY_H
